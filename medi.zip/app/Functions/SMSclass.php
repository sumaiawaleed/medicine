<?php


namespace App\Functions;

class SMSclass
{
    public function sendMessage($phone, $code, $msg = "")
    {
        return true;
    }


}
